-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2022 at 10:46 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `almas_stone`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `name`, `image`, `body`, `tags`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'te2', '{\"indexArray\":{\"large\":\"images\\\\blogs-images\\\\2021\\\\11\\\\27\\\\1638014323\\\\1638014323_large.jpg\",\"medium\":\"images\\\\blogs-images\\\\2021\\\\11\\\\27\\\\1638014323\\\\1638014323_medium.jpg\",\"small\":\"images\\\\blogs-images\\\\2021\\\\11\\\\27\\\\1638014323\\\\1638014323_small.jpg\"},\"directory\":\"images\\\\blogs-images\\\\2021\\\\11\\\\27\\\\1638014323\",\"currentImage\":\"medium\"}', 'tgea sd sa dsasa', 'test', 1, '2021-11-27 08:28:44', '2021-11-28 16:50:49', NULL),
(3, 'asda', '{\"indexArray\":{\"large\":\"..\\/storage\\/images\\\\user-photo\\\\2021\\\\11\\\\27\\\\1638037054\\\\1638037054_large.jpg\",\"medium\":\"..\\/storage\\/images\\\\user-photo\\\\2021\\\\11\\\\27\\\\1638037054\\\\1638037054_medium.jpg\",\"small\":\"..\\/storage\\/images\\\\user-photo\\\\2021\\\\11\\\\27\\\\1638037054\\\\1638037054_small.jpg\"},\"directory\":\"..\\/storage\\/images\\\\user-photo\\\\2021\\\\11\\\\27\\\\1638037054\",\"currentImage\":\"medium\"}', 'dasdasdas', 'asd', 0, '2021-11-27 14:47:35', '2021-11-27 14:50:31', '2021-11-27 14:50:31'),
(4, 'test', '{\"indexArray\":{\"large\":\"images\\\\blogs-images\\\\2021\\\\11\\\\29\\\\1638190745\\\\1638190745_large.jpg\",\"medium\":\"images\\\\blogs-images\\\\2021\\\\11\\\\29\\\\1638190745\\\\1638190745_medium.jpg\",\"small\":\"images\\\\blogs-images\\\\2021\\\\11\\\\29\\\\1638190745\\\\1638190745_small.jpg\"},\"directory\":\"images\\\\blogs-images\\\\2021\\\\11\\\\29\\\\1638190745\",\"currentImage\":\"medium\"}', 'testa A', 'tes,yes,ok', 1, '2021-11-29 09:29:05', '2021-11-30 15:30:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

CREATE TABLE `galleries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `galleries`
--

INSERT INTO `galleries` (`id`, `name`, `image`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'sdf', '{\"indexArray\":{\"large\":\"images\\\\gallery-images\\\\2021\\\\11\\\\26\\\\1637946222\\\\1637946222_large.jpg\",\"medium\":\"images\\\\gallery-images\\\\2021\\\\11\\\\26\\\\1637946222\\\\1637946222_medium.jpg\",\"small\":\"images\\\\gallery-images\\\\2021\\\\11\\\\26\\\\1637946222\\\\1637946222_small.jpg\"},\"directory\":\"images\\\\gallery-images\\\\2021\\\\11\\\\26\\\\1637946222\",\"currentImage\":\"small\"}', 1, '2021-11-26 13:33:43', '2022-05-27 16:06:30', '2022-05-27 16:06:30'),
(3, 'test', '{\"indexArray\":{\"large\":\"images\\\\gallery-images\\\\2021\\\\11\\\\29\\\\1638189322\\\\1638189322_large.jpg\",\"medium\":\"images\\\\gallery-images\\\\2021\\\\11\\\\29\\\\1638189322\\\\1638189322_medium.jpg\",\"small\":\"images\\\\gallery-images\\\\2021\\\\11\\\\29\\\\1638189322\\\\1638189322_small.jpg\"},\"directory\":\"images\\\\gallery-images\\\\2021\\\\11\\\\29\\\\1638189322\",\"currentImage\":\"large\"}', 1, '2021-11-29 09:05:22', '2022-05-27 16:06:26', '2022-05-27 16:06:26'),
(4, 'pic1', '{\"indexArray\":{\"large\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683820\\\\1653683820_large.jpg\",\"medium\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683820\\\\1653683820_medium.jpg\",\"small\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683820\\\\1653683820_small.jpg\"},\"directory\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683820\",\"currentImage\":\"large\"}', 1, '2022-05-27 16:07:01', '2022-05-27 16:07:50', NULL),
(5, 'pic2', '{\"indexArray\":{\"large\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683845\\\\1653683845_large.jpg\",\"medium\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683845\\\\1653683845_medium.jpg\",\"small\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683845\\\\1653683845_small.jpg\"},\"directory\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683845\",\"currentImage\":\"small\"}', 1, '2022-05-27 16:07:25', '2022-05-27 16:07:25', NULL),
(6, 'pic3', '{\"indexArray\":{\"large\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683866\\\\1653683866_large.jpg\",\"medium\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683866\\\\1653683866_medium.jpg\",\"small\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683866\\\\1653683866_small.jpg\"},\"directory\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683866\",\"currentImage\":\"medium\"}', 1, '2022-05-27 16:07:46', '2022-05-27 16:07:51', NULL),
(7, 'pic4', '{\"indexArray\":{\"large\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683890\\\\1653683890_large.jpg\",\"medium\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683890\\\\1653683890_medium.jpg\",\"small\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683890\\\\1653683890_small.jpg\"},\"directory\":\"images\\\\gallery-images\\\\2022\\\\05\\\\27\\\\1653683890\",\"currentImage\":\"small\"}', 1, '2022-05-27 16:08:10', '2022-05-27 16:08:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `lyrics`
--

CREATE TABLE `lyrics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lyrics`
--

INSERT INTO `lyrics` (`id`, `name`, `body`, `status`, `category_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'حبیب', 'ای دیر به دست امده و زود برفتی', 0, 4, '2021-11-26 09:39:33', '2021-11-26 10:21:33', '2021-11-26 10:21:33'),
(2, 'خبری', 'ای دیر به دست امده و زود برفتی', 1, 4, '2021-11-26 09:48:12', '2021-11-30 12:46:38', NULL),
(3, 'حبیب', 'ای دیر به دست امده و زود برفتی ای دیر به دست امده و زود برفتی  ای دیر به دست امده و زود برفتی  ای دیر به دست امده و زود برفتی  ای دیر به دست امده و زود برفتی', 1, 4, '2021-11-26 09:48:43', '2021-11-30 12:54:17', NULL),
(4, 'جویی تربیانی', 'تیسب سیب سیبسی', 1, 5, '2021-11-30 11:15:21', '2021-11-30 12:54:36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `lyric_categories`
--

CREATE TABLE `lyric_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lyric_categories`
--

INSERT INTO `lyric_categories` (`id`, `name`, `image`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'اشعار مادر', '{\"indexArray\":{\"large\":\"images\\\\lyric-category\\\\2021\\\\11\\\\25\\\\1637872395\\\\1637872395_large.jpg\",\"medium\":\"images\\\\lyric-category\\\\2021\\\\11\\\\25\\\\1637872395\\\\1637872395_medium.jpg\",\"small\":\"images\\\\lyric-category\\\\2021\\\\11\\\\25\\\\1637872395\\\\1637872395_small.jpg\"},\"directory\":\"images\\\\lyric-category\\\\2021\\\\11\\\\25\\\\1637872395\",\"currentImage\":\"medium\"}', 1, '2021-11-25 17:03:15', '2021-11-25 17:04:06', '2021-11-25 17:04:06'),
(3, 'اشعار مادر', '{\"indexArray\":{\"large\":\"images\\\\lyric-category\\\\2021\\\\11\\\\25\\\\1637872423\\\\1637872423_large.jpg\",\"medium\":\"images\\\\lyric-category\\\\2021\\\\11\\\\25\\\\1637872423\\\\1637872423_medium.jpg\",\"small\":\"images\\\\lyric-category\\\\2021\\\\11\\\\25\\\\1637872423\\\\1637872423_small.jpg\"},\"directory\":\"images\\\\lyric-category\\\\2021\\\\11\\\\25\\\\1637872423\",\"currentImage\":\"medium\"}', 1, '2021-11-25 17:03:43', '2021-11-25 17:03:57', '2021-11-25 17:03:57'),
(4, 'اشعار همسر دوم', '{\"indexArray\":{\"large\":\"images\\\\lyric-category\\\\2021\\\\11\\\\26\\\\1637929553\\\\1637929553_large.jpg\",\"medium\":\"images\\\\lyric-category\\\\2021\\\\11\\\\26\\\\1637929553\\\\1637929553_medium.jpg\",\"small\":\"images\\\\lyric-category\\\\2021\\\\11\\\\26\\\\1637929553\\\\1637929553_small.jpg\"},\"directory\":\"images\\\\lyric-category\\\\2021\\\\11\\\\26\\\\1637929553\",\"currentImage\":\"medium\"}', 1, '2021-11-25 17:04:35', '2021-11-29 18:05:50', NULL),
(5, 'تست', '{\"indexArray\":{\"large\":\"images\\\\lyric-category\\\\2021\\\\11\\\\30\\\\1638283497\\\\1638283497_large.jpg\",\"medium\":\"images\\\\lyric-category\\\\2021\\\\11\\\\30\\\\1638283497\\\\1638283497_medium.jpg\",\"small\":\"images\\\\lyric-category\\\\2021\\\\11\\\\30\\\\1638283497\\\\1638283497_small.jpg\"},\"directory\":\"images\\\\lyric-category\\\\2021\\\\11\\\\30\\\\1638283497\",\"currentImage\":\"medium\"}', 1, '2021-11-30 11:14:58', '2021-11-30 11:14:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(5, '2014_10_12_000000_create_users_table', 1),
(6, '2014_10_12_100000_create_password_resets_table', 1),
(7, '2019_08_19_000000_create_failed_jobs_table', 1),
(8, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(9, '2021_11_25_191411_create_sliders_table', 2),
(10, '2021_11_25_191604_create_blogs_table', 3),
(11, '2021_11_25_191706_create_galleries_table', 4),
(12, '2021_11_25_191856_create_lyric_categories_table', 5),
(13, '2021_11_25_192004_create_lyrics_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `name`, `image`, `body`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 'ئشی', '\"images\\\\sliders-images\\\\2021\\\\11\\\\27\\\\1638033586.jpg\"', 'شسیشسشیس', 1, '2021-11-27 12:08:10', '2021-11-27 13:49:53', '2021-11-27 13:49:53'),
(4, 'اسلایدر 1', '\"images\\\\sliders-images\\\\2021\\\\11\\\\27\\\\1638033633.jpg\"', 'اسلایدر شماره 1', 1, '2021-11-27 13:50:34', '2021-11-29 17:02:03', '2021-11-29 17:02:03'),
(5, 'بهترین نوع سنگ', '\"images\\\\sliders-images\\\\2021\\\\11\\\\29\\\\1638217962.jpg\"', 'بهترین نوع سنگ بهترین نوع سنگ بهترین نوع سنگ', 1, '2021-11-29 17:02:42', '2022-05-27 16:03:26', '2022-05-27 16:03:26'),
(6, 'slide 1', '\"images\\\\sliders-images\\\\2022\\\\05\\\\27\\\\1653683628.jpg\"', 'slider 1', 1, '2022-05-27 16:03:48', '2022-05-27 16:03:48', NULL),
(7, 'slider 2', '\"images\\\\sliders-images\\\\2022\\\\05\\\\27\\\\1653683651.jpg\"', 'slider 2', 1, '2022-05-27 16:04:11', '2022-05-27 16:04:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'avatar',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `password`, `role`, `image`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 'جویی تربیانی', 'white@gmail.com', '09034668992', '$2y$10$j3vAO4wd7X0xaHaWrwX6YODMm6sDHPYh9EFKckCKOtyJWPGcrY7My', 1, '{\"indexArray\":{\"large\":\"images\\\\user-image\\\\2021\\\\11\\\\28\\\\1638130161\\\\1638130161_large.jpg\",\"medium\":\"images\\\\user-image\\\\2021\\\\11\\\\28\\\\1638130161\\\\1638130161_medium.jpg\",\"small\":\"images\\\\user-image\\\\2021\\\\11\\\\28\\\\1638130161\\\\1638130161_small.jpg\"},\"directory\":\"images\\\\user-image\\\\2021\\\\11\\\\28\\\\1638130161\",\"currentImage\":\"medium\"}', NULL, '2021-11-27 16:38:04', '2021-11-28 16:39:21', NULL),
(6, 'جویی تربیانی', 'demo@gmail.com', '0915-321-8686', '$2y$10$f0UP06m.u/in2dEKZbFJh./2Zp5EAu6t1xZRax2yQDv.tM5M8yhye', 0, '{\"indexArray\":{\"large\":\"images\\\\user-image\\\\2022\\\\05\\\\27\\\\1653683235\\\\1653683235_large.jpg\",\"medium\":\"images\\\\user-image\\\\2022\\\\05\\\\27\\\\1653683235\\\\1653683235_medium.jpg\",\"small\":\"images\\\\user-image\\\\2022\\\\05\\\\27\\\\1653683235\\\\1653683235_small.jpg\"},\"directory\":\"images\\\\user-image\\\\2022\\\\05\\\\27\\\\1653683235\",\"currentImage\":\"medium\"}', NULL, '2021-11-28 11:08:27', '2022-05-27 15:57:15', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lyrics`
--
ALTER TABLE `lyrics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lyrics_category_id_foreign` (`category_id`);

--
-- Indexes for table `lyric_categories`
--
ALTER TABLE `lyric_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_mobile_unique` (`mobile`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lyrics`
--
ALTER TABLE `lyrics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lyric_categories`
--
ALTER TABLE `lyric_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `lyrics`
--
ALTER TABLE `lyrics`
  ADD CONSTRAINT `lyrics_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `lyric_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
